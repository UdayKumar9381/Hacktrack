const hackathonData = {
    2021: {
      firstYearProjects: {
              January: [
                // 8 python-related projects
                { 
                  name: 'Simple Calculator', 
                  technologies: ['Python'], 
                  description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
                  image: '/images/simp cal.jpg'
                },
                { 
                  name: 'To-Do List Application', 
                  technologies: ['Python'], 
                  description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
                  image: '/images/To-Do.jpg'
                },
                { 
                  name: 'Number Guessing Game', 
                  technologies: ['Python'], 
                  description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
                  image: '/images/number.jpg'
                },
                { 
                  name: 'Weather App', 
                  technologies: ['Python'], 
                  description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
                  image: '/images/weather.jpg'
                },
                { 
                  name: 'Simple Alarm Clock', 
                  technologies: ['Python'], 
                  description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
                  image: '/images/alarm.jpg'
                },
                { 
                  name: 'BMI Calculator', 
                  technologies: ['Python'], 
                  description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
                  image: '/images/BMI.jpg'
                },
                { 
                  name: 'Palindrome Checker', 
                  technologies: ['Python'], 
                  description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
                  image: '/images/palindrome.jpg'
                },
                { 
                  name: 'Simple Countdown Timer', 
                  technologies: ['Python'], 
                  description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
                  image: '/images/countdown.jpg'
                },
              ],
        
              February: [
                // 8 Basic NLP-related projects
                { 
                  name: 'Text Classification with NLTK', 
                  technologies: ['Python', 'NLTK'], 
                  description: 'Perform text classification using NLTK and machine learning algorithms.',
                  image: '/images/text.jpg'
                },
                { 
                  name: ' Named Entity Recognition with spaCy', 
                  technologies: ['Python', 'spaCy'], 
                  description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
                  image: '/images/name.jpg'
                },
                { 
                  name: ' Sentiment Analysis with HuggingFace Transformers', 
                  technologies: ['Python', 'Transformers'], 
                  description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
                  image: '/images/senti.jpg'
                },
                { 
                  name: ' Topic Modeling with Gensim', 
                  technologies: ['Python', 'Gensim'], 
                  description: 'Perform topic modeling on a collection of texts using Gensim library.',
                  image: '/images/genism.jpg'
                },
                { 
                  name: ' Text Classification with TextBlob', 
                  technologies: ['Python', 'TextBlob'], 
                  description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
                  image: '/images/text.jpg'
                },
                { 
                  name: 'Dependency Parsing with StanfordNLP', 
                  technologies: ['Python', 'StanfordNLP'], 
                  description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
                  image: '/images/parsing.jpg'
                },
                { 
                  name: ' Question Answering with BERT', 
                  technologies: ['Python', 'BERT'], 
                  description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
                  image: '/images/question.jpg'
                },
                { 
                  name: ' Word Embeddings with GloVe', 
                  technologies: ['Python', 'GloVe'], 
                  description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
                  image: '/images/word.jpg'
                },
              ],
        
              March: 
              // 8 Basic ML-related projects
              [
                { 
                  name: 'House Price Prediction', 
                  technologies: ['Python', 'Scikit-Learn'], 
                  description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
                  image: '/images/house_price.jpg'
                },
                { 
                  name: 'Iris Flower Classification', 
                  technologies: ['Python', 'Scikit-Learn'], 
                  description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
                  image: '/images/iris.jpg'
                },
                { 
                  name: 'Customer Churn Prediction', 
                  technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
                  description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
                  image: '/images/customer_churn.jpg'
                },
                { 
                  name: 'Digit Recognizer', 
                  technologies: ['Python', 'TensorFlow'], 
                  description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
                  image: '/images/digit_recognizer.jpg'
                },
                { 
                  name: 'Sentiment Analysis', 
                  technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
                  description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
                  image: '/images/sentiment.jpg'
                },
                { 
                  name: 'Stock Price Prediction', 
                  technologies: ['Python', 'Pandas', 'TensorFlow'], 
                  description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
                  image: '/images/stock_price.jpg'
                },
                { 
                  name: 'Spam Email Classifier', 
                  technologies: ['Python', 'Scikit-Learn'], 
                  description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
                  image: '/images/spam_classifier.jpg'
                },
                { 
                  name: 'Weather Forecasting', 
                  technologies: ['Python', 'Scikit-Learn'], 
                  description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
                  image: '/images/weather_forecasting.jpg'
                }
              ],
        
                April: [
                  { 
                    name: 'Image Classification', 
                    technologies: ['Python', 'TensorFlow', 'Keras'], 
                    description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
                    image: '/images/image_classification.jpg'
                  },
                  { 
                    name: 'Handwritten Digit Recognition', 
                    technologies: ['Python', 'TensorFlow', 'Keras'], 
                    description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
                    image: '/images/handwritten_digits.jpg'
                  },
                  { 
                    name: 'Object Detection', 
                    technologies: ['Python', 'YOLO', 'OpenCV'], 
                    description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
                    image: '/images/object_detection.jpg'
                  },
                  { 
                    name: 'Text Generation', 
                    technologies: ['Python', 'TensorFlow', 'Keras'], 
                    description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
                    image: '/images/text_generation.jpg'
                  },
                  { 
                    name: 'Style Transfer', 
                    technologies: ['Python', 'TensorFlow'], 
                    description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
                    image: '/images/style_transfer.jpg'
                  },
                  { 
                    name: 'Face Recognition', 
                    technologies: ['Python', 'OpenCV', 'FaceNet'], 
                    description: 'Build a face recognition system to identify and verify people based on facial features.',
                    image: '/images/face_recognition.jpg'
                  },
                  { 
                    name: 'Sentiment Analysis with RNNs', 
                    technologies: ['Python', 'TensorFlow', 'Keras'], 
                    description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
                    image: '/images/sentiment_analysis.jpg'
                  },
                  { 
                    name: 'Speech-to-Text', 
                    technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
                    description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
                    image: '/images/speech_to_text.jpg'
                  }
                ],


                May: [
                  { 
                    name: 'Edge Detection', 
                    technologies: ['Python', 'OpenCV'], 
                    description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
                    image: '/images/edge_detection.jpg'
                  },
                  { 
                    name: 'Face Detection', 
                    technologies: ['Python', 'OpenCV'], 
                    description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
                    image: '/images/face_detection.jpg'
                  },
                  { 
                    name: 'Color Detection', 
                    technologies: ['Python', 'OpenCV'], 
                    description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
                    image: '/images/color_detection.jpg'
                  },
                  { 
                    name: 'Motion Detection', 
                    technologies: ['Python', 'OpenCV'], 
                    description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
                    image: '/images/motion_detection.jpg'
                  },
                  { 
                    name: 'Object Tracking', 
                    technologies: ['Python', 'OpenCV'], 
                    description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
                    image: '/images/object_tracking.jpg'
                  },
                  { 
                    name: 'Image Filtering', 
                    technologies: ['Python', 'OpenCV'], 
                    description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
                    image: '/images/image_filtering.jpg'
                  },
                  { 
                    name: 'Cartoonify Image', 
                    technologies: ['Python', 'OpenCV'], 
                    description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
                    image: '/images/cartoonify.jpg'
                  },
                  { 
                    name: 'QR Code Scanner', 
                    technologies: ['Python', 'OpenCV', 'Pyzbar'], 
                    description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
                    image: '/images/qr_scanner.jpg'
                  }
                ],

                June: [
                  { 
                    name: 'Line Follower Robot', 
                    technologies: ['Arduino', 'IR Sensors', 'Motors'], 
                    description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
                    image: '/images/line_follower.jpg'
                  },
                  { 
                    name: 'Obstacle Avoidance Robot', 
                    technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
                    description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
                    image: '/images/obstacle_avoidance.jpg'
                  },
                  { 
                    name: 'Light Following Robot', 
                    technologies: ['Arduino', 'Light Sensors', 'Motors'], 
                    description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
                    image: '/images/light_following.jpg'
                  },
                  { 
                    name: 'Bluetooth-Controlled Robot', 
                    technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
                    description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
                    image: '/images/bluetooth_robot.jpg'
                  },
                  { 
                    name: 'Remote-Controlled Car', 
                    technologies: ['Arduino', 'RF Module', 'Motors'], 
                    description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
                    image: '/images/rc_car.jpg'
                  },
                  { 
                    name: 'Basic Robotic Arm', 
                    technologies: ['Arduino', 'Servo Motors'], 
                    description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
                    image: '/images/robotic_arm.jpg'
                  },
                  { 
                    name: 'Maze Solver Robot', 
                    technologies: ['Arduino', 'IR Sensors', 'Motors'], 
                    description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
                    image: '/images/maze_solver.jpg'
                  },
                  { 
                    name: 'Voice-Controlled Robot', 
                    technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
                    description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
                    image: '/images/voice_controlled.jpg'
                  }
                ],
              
        
              July: [
                // 8 NLP + ML Hybrid projects
                  { 
                    name: 'Sentiment Analysis', 
                    technologies: ['Python', 'scikit-learn', 'NLTK'], 
                    description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
                    image: '/images/sentiment_analysis.jpg'
                  },
                  { 
                    name: 'Spam Email Classifier', 
                    technologies: ['Python', 'scikit-learn', 'NLTK'], 
                    description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
                    image: '/images/spam_classifier.jpg'
                  },
                  { 
                    name: 'Text Summarization', 
                    technologies: ['Python', 'Gensim', 'NLTK'], 
                    description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
                    image: '/images/text_summarization.jpg'
                  },
                  { 
                    name: 'Named Entity Recognition (NER)', 
                    technologies: ['Python', 'spaCy'], 
                    description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
                    image: '/images/ner_system.jpg'
                  },
                  { 
                    name: 'Chatbot with Machine Learning', 
                    technologies: ['Python', 'TensorFlow', 'NLTK'], 
                    description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
                    image: '/images/chatbot.jpg'
                  },
                  { 
                    name: 'Language Detection', 
                    technologies: ['Python', 'scikit-learn', 'NLTK'], 
                    description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
                    image: '/images/language_detection.jpg'
                  },
                  { 
                    name: 'Topic Modeling', 
                    technologies: ['Python', 'Gensim', 'NLTK'], 
                    description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
                    image: '/images/topic_modeling.jpg'
                  },
                  { 
                    name: 'Keyword Extraction', 
                    technologies: ['Python', 'spaCy', 'TextRank'], 
                    description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
                    image: '/images/keyword_extraction.jpg'
                  }
                ],
                
              August: [
                // 8 Computer Vision-related projects
                  { 
                    name: 'Face Detection with Real-Time Video', 
                    technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
                    description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
                    image: '/images/face_detection_video.jpg'
                  },
                  { 
                    name: 'Gesture Recognition', 
                    technologies: ['Python', 'OpenCV', 'MediaPipe'], 
                    description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
                    image: '/images/gesture_recognition.jpg'
                  },
                  { 
                    name: 'Object Recognition', 
                    technologies: ['Python', 'OpenCV', 'TensorFlow'], 
                    description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
                    image: '/images/object_recognition.jpg'
                  },
                  { 
                    name: 'Eye Blink Detection', 
                    technologies: ['Python', 'OpenCV', 'dlib'], 
                    description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
                    image: '/images/eye_blink_detection.jpg'
                  },
                  { 
                    name: 'Optical Character Recognition (OCR)', 
                    technologies: ['Python', 'OpenCV', 'Tesseract'], 
                    description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
                    image: '/images/ocr.jpg'
                  },
                  { 
                    name: 'Image Classification', 
                    technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
                    description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
                    image: '/images/image_classification.jpg'
                  },
                  { 
                    name: 'Real-Time Object Tracking', 
                    technologies: ['Python', 'OpenCV'], 
                    description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
                    image: '/images/object_tracking.jpg'
                  },
                  { 
                    name: 'Image Segmentation', 
                    technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
                    description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
                    image: '/images/image_segmentation.jpg'
                  }
                ],
                
              September: [
                // 8 AI-based chatbots projects
                  { 
                    name: 'Customer Support Chatbot', 
                    technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
                    description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
                    image: '/images/customer_support_chatbot.jpg'
                  },
                  { 
                    name: 'Personal Assistant Chatbot', 
                    technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
                    description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
                    image: '/images/personal_assistant.jpg'
                  },
                  { 
                    name: 'E-commerce Recommendation Bot', 
                    technologies: ['Python', 'scikit-learn', 'Flask'], 
                    description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
                    image: '/images/ecommerce_chatbot.jpg'
                  },
                  { 
                    name: 'Healthcare Assistant Bot', 
                    technologies: ['Python', 'TensorFlow', 'NLTK'], 
                    description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
                    image: '/images/healthcare_bot.jpg'
                  },
                  { 
                    name: 'Travel Guide Chatbot', 
                    technologies: ['Python', 'Dialogflow', 'Flask'], 
                    description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
                    image: '/images/travel_guide_bot.jpg'
                  },
                  { 
                    name: 'Language Learning Bot', 
                    technologies: ['Python', 'TensorFlow', 'NLTK'], 
                    description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
                    image: '/images/language_learning_bot.jpg'
                  },
                  { 
                    name: 'Mental Health Chatbot', 
                    technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
                    description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
                    image: '/images/mental_health_bot.jpg'
                  },
                  { 
                    name: 'Finance Assistant Chatbot', 
                    technologies: ['Python', 'Flask', 'scikit-learn'], 
                    description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
                    image: '/images/finance_assistant.jpg'
                  },    
              ],

            October: [
              // 8 MERN projects
                { 
                  name: 'Personal Portfolio Website', 
                  technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
                  description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
                  image: '/images/portfolio_website.jpg'
                },
                { 
                  name: 'Blog Platform', 
                  technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
                  description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
                  image: '/images/blog_platform.jpg'
                },
                { 
                  name: 'E-commerce Website', 
                  technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
                  description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
                  image: '/images/ecommerce_website.jpg'
                },
                { 
                  name: 'Real-time Chat Application', 
                  technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
                  description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
                  image: '/images/chat_application.jpg'
                },
                { 
                  name: 'Task Management Application', 
                  technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
                  description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
                  image: '/images/task_management.jpg'
                },
                { 
                  name: 'Job Board Website', 
                  technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
                  description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
                  image: '/images/job_board.jpg'
                },
                { 
                  name: 'Social Media Platform', 
                  technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
                  description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
                  image: '/images/social_media_platform.jpg'
                },
                { 
                  name: 'Online Learning Management System', 
                  technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
                  description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
                  image: '/images/learning_management.jpg'
                },
              ],

            November: [
              // 8 Flask projects
                { 
                  name: 'Personal Blog', 
                  technologies: ['Python', 'Flask', 'SQLite'], 
                  description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
                  image: '/images/personal_blog.jpg'
                },
                { 
                  name: 'Task Manager Application', 
                  technologies: ['Python', 'Flask', 'SQLite'], 
                  description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
                  image: '/images/task_manager.jpg'
                },
                { 
                  name: 'Online Portfolio Website', 
                  technologies: ['Python', 'Flask', 'SQLAlchemy'], 
                  description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
                  image: '/images/portfolio_website.jpg'
                },
                { 
                  name: 'Weather Application', 
                  technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
                  description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
                  image: '/images/weather_app.jpg'
                },
                { 
                  name: 'Recipe Sharing Platform', 
                  technologies: ['Python', 'Flask', 'MySQL'], 
                  description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
                  image: '/images/recipe_sharing.jpg'
                },
                { 
                  name: 'Blog with Admin Panel', 
                  technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
                  description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
                  image: '/images/admin_blog.jpg'
                },
                { 
                  name: 'Login and Registration System', 
                  technologies: ['Python', 'Flask', 'SQLAlchemy'], 
                  description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
                  image: '/images/login_system.jpg'
                },
                { 
                  name: 'Real-time Chat Application', 
                  technologies: ['Python', 'Flask', 'Socket.IO'], 
                  description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
                  image: '/images/chat_application.jpg'
                },
              ],
          
            December: [
              // 8 Full-stack projects
                { 
                  name: 'E-Commerce Website', 
                  technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
                  description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
                  image: '/images/ecommerce.jpg'
                },
                { 
                  name: 'Blog Platform', 
                  technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
                  description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
                  image: '/images/blog_platform.jpg'
                },
                { 
                  name: 'Social Media App', 
                  technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
                  description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
                  image: '/images/social_media.jpg'
                },
                { 
                  name: 'Task Management App', 
                  technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
                  description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
                  image: '/images/task_manager.jpg'
                },
                { 
                  name: 'Real-Time Chat Application', 
                  technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
                  description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
                  image: '/images/chat_application.jpg'
                },
                { 
                  name: 'Job Portal', 
                  technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
                  description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
                  image: '/images/job_portal.jpg'
                },
                { 
                  name: 'Event Booking System', 
                  technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
                  description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
                  image: '/images/event_booking.jpg'
                },
                { 
                  name: 'Online Learning Platform', 
                  technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
                  description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
                  image: '/images/learning_platform.jpg'
                },
              ],
      },
        
      secondYearProjects: {
        January: [
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: '/images/text.jpg'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: '/images/name.jpg'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: '/images/senti.jpg'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: '/images/genism.jpg'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: '/images/text.jpg'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: '/images/parsing.jpg'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: '/images/question.jpg'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: '/images/word.jpg'
          },
        ],
        
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],


          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],


          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ],
      },
  
      thirdYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: '/images/text.jpg'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: '/images/name.jpg'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: '/images/senti.jpg'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: '/images/genism.jpg'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: '/images/text.jpg'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: '/images/parsing.jpg'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: '/images/question.jpg'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: '/images/word.jpg'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ],
      },
  
      fourthYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: '/images/text.jpg'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: '/images/name.jpg'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: '/images/senti.jpg'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: '/images/genism.jpg'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: '/images/text.jpg'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: '/images/parsing.jpg'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: '/images/question.jpg'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: '/images/word.jpg'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],

          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ],
      },
    },
  
    2022: {
      firstYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ]
      },
      secondYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
       ]
      },
      thirdYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
       ]
      },
      fourthYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
      
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
       ]
      },
    },
  
    2023: {
      firstYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ]
      },
      secondYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ]
      },
      thirdYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ]
      },
      fourthYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ]
      },
    },
  
    2024: {
      firstYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ]
      },
      secondYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ]
      },
      thirdYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ]
      },
      fourthYearProjects: {
        January: [
          // 8 NLP-related projects
          { 
            name: 'Text Classification with NLTK', 
            technologies: ['Python', 'NLTK'], 
            description: 'Perform text classification using NLTK and machine learning algorithms.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Named Entity Recognition with spaCy', 
            technologies: ['Python', 'spaCy'], 
            description: 'Use spaCy for Named Entity Recognition (NER) to identify and classify entities in text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Sentiment Analysis with HuggingFace Transformers', 
            technologies: ['Python', 'Transformers'], 
            description: 'Analyze the sentiment of a given text using HuggingFace Transformers models.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Topic Modeling with Gensim', 
            technologies: ['Python', 'Gensim'], 
            description: 'Perform topic modeling on a collection of texts using Gensim library.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Text Classification with TextBlob', 
            technologies: ['Python', 'TextBlob'], 
            description: 'Classify text into different categories using the TextBlob library for sentiment analysis.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: 'Dependency Parsing with StanfordNLP', 
            technologies: ['Python', 'StanfordNLP'], 
            description: 'Use StanfordNLP for syntactic analysis and dependency parsing of a given text.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Question Answering with BERT', 
            technologies: ['Python', 'BERT'], 
            description: 'Build a question answering system based on the BERT (Bidirectional Encoder Representations from Transformers) model.',
            image: 'https://via.placeholder.com/150'
          },
          { 
            name: ' Word Embeddings with GloVe', 
            technologies: ['Python', 'GloVe'], 
            description: 'Learn and apply word embeddings using GloVe (Global Vectors for Word Representation).',
            image: 'https://via.placeholder.com/150'
          },
        ],
  
        February: [
          // 8 Basic Python-related projects
          { 
            name: 'Simple Calculator', 
            technologies: ['Python'], 
            description: 'Create a simple calculator that can perform basic operations like addition, subtraction, multiplication, and division.',
            image: '/images/simp cal.jpg'
          },
          { 
            name: 'To-Do List Application', 
            technologies: ['Python'], 
            description: 'Build a console-based to-do list application where users can add, delete, and view tasks.',
            image: '/images/To-Do.jpg'
          },
          { 
            name: 'Number Guessing Game', 
            technologies: ['Python'], 
            description: 'Create a simple number guessing game where the user has to guess a randomly generated number within a specific range.',
            image: '/images/number.jpg'
          },
          { 
            name: 'Weather App', 
            technologies: ['Python'], 
            description: 'Build a basic weather application that fetches and displays the weather information for a specific city using an API.',
            image: '/images/weather.jpg'
          },
          { 
            name: 'Simple Alarm Clock', 
            technologies: ['Python'], 
            description: 'Create a simple alarm clock application where the user can set an alarm at a specific time.',
            image: '/images/alarm.jpg'
          },
          { 
            name: 'BMI Calculator', 
            technologies: ['Python'], 
            description: 'Develop a basic BMI (Body Mass Index) calculator that calculates the BMI based on user input (height and weight).',
            image: '/images/BMI.jpg'
          },
          { 
            name: 'Palindrome Checker', 
            technologies: ['Python'], 
            description: 'Create a program that checks if a given string is a palindrome (reads the same backward and forward).',
            image: '/images/palindrome.jpg'
          },
          { 
            name: 'Simple Countdown Timer', 
            technologies: ['Python'], 
            description: 'Build a countdown timer where the user can input a time, and it will count down until reaching zero.',
            image: '/images/countdown.jpg'
          },
        ],
  
        March: 
        // 8 Basic ML-related projects
        [
          { 
            name: 'House Price Prediction', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Create a model to predict house prices based on features like size, number of rooms, and location using linear regression.',
            image: '/images/house_price.jpg'
          },
          { 
            name: 'Iris Flower Classification', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a classification model to classify iris flowers into different species based on sepal and petal dimensions.',
            image: '/images/iris.jpg'
          },
          { 
            name: 'Customer Churn Prediction', 
            technologies: ['Python', 'Pandas', 'Scikit-Learn'], 
            description: 'Develop a logistic regression model to predict whether a customer will churn based on their usage and demographics.',
            image: '/images/customer_churn.jpg'
          },
          { 
            name: 'Digit Recognizer', 
            technologies: ['Python', 'TensorFlow'], 
            description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
            image: '/images/digit_recognizer.jpg'
          },
          { 
            name: 'Sentiment Analysis', 
            technologies: ['Python', 'NLTK', 'Scikit-Learn'], 
            description: 'Analyze the sentiment of text reviews (positive or negative) using a bag-of-words approach or TF-IDF.',
            image: '/images/sentiment.jpg'
          },
          { 
            name: 'Stock Price Prediction', 
            technologies: ['Python', 'Pandas', 'TensorFlow'], 
            description: 'Create a model to predict stock prices using historical stock data and a simple LSTM network.',
            image: '/images/stock_price.jpg'
          },
          { 
            name: 'Spam Email Classifier', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a model to classify emails as spam or not spam using Naive Bayes or a similar algorithm.',
            image: '/images/spam_classifier.jpg'
          },
          { 
            name: 'Weather Forecasting', 
            technologies: ['Python', 'Scikit-Learn'], 
            description: 'Build a simple model to predict weather conditions (e.g., temperature or rainfall) using historical weather data.',
            image: '/images/weather_forecasting.jpg'
          }
        ],
  
          April: [
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Build a convolutional neural network (CNN) to classify images from the CIFAR-10 dataset.',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Handwritten Digit Recognition', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use the MNIST dataset to build a neural network that recognizes handwritten digits.',
              image: '/images/handwritten_digits.jpg'
            },
            { 
              name: 'Object Detection', 
              technologies: ['Python', 'YOLO', 'OpenCV'], 
              description: 'Implement an object detection model using YOLO to detect and classify objects in images or video streams.',
              image: '/images/object_detection.jpg'
            },
            { 
              name: 'Text Generation', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an LSTM network to generate text based on a given input, such as simulating how an author writes.',
              image: '/images/text_generation.jpg'
            },
            { 
              name: 'Style Transfer', 
              technologies: ['Python', 'TensorFlow'], 
              description: 'Implement neural style transfer to combine the content of one image with the artistic style of another.',
              image: '/images/style_transfer.jpg'
            },
            { 
              name: 'Face Recognition', 
              technologies: ['Python', 'OpenCV', 'FaceNet'], 
              description: 'Build a face recognition system to identify and verify people based on facial features.',
              image: '/images/face_recognition.jpg'
            },
            { 
              name: 'Sentiment Analysis with RNNs', 
              technologies: ['Python', 'TensorFlow', 'Keras'], 
              description: 'Use an RNN model to analyze the sentiment of text data, such as movie reviews or tweets.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Speech-to-Text', 
              technologies: ['Python', 'DeepSpeech', 'PyTorch'], 
              description: 'Build a model to convert spoken audio into text using a pre-trained speech-to-text deep learning model.',
              image: '/images/speech_to_text.jpg'
            }
          ],
          May: [
            { 
              name: 'Edge Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Use OpenCV to perform edge detection on images using algorithms like Canny Edge Detector.',
              image: '/images/edge_detection.jpg'
            },
            { 
              name: 'Face Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Detect faces in images or video streams using Haar cascades or DNN-based face detectors.',
              image: '/images/face_detection.jpg'
            },
            { 
              name: 'Color Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Create a program that detects and highlights specific colors in an image using HSV color space.',
              image: '/images/color_detection.jpg'
            },
            { 
              name: 'Motion Detection', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Build a motion detection system that detects moving objects in video feeds using background subtraction.',
              image: '/images/motion_detection.jpg'
            },
            { 
              name: 'Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Implement object tracking using algorithms like CSRT or KCF to follow an object in a video stream.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Filtering', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Apply different image filters like Gaussian Blur, Median Blur, or Bilateral Filters to enhance images.',
              image: '/images/image_filtering.jpg'
            },
            { 
              name: 'Cartoonify Image', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Convert a regular image into a cartoon-like image using edge detection and color quantization.',
              image: '/images/cartoonify.jpg'
            },
            { 
              name: 'QR Code Scanner', 
              technologies: ['Python', 'OpenCV', 'Pyzbar'], 
              description: 'Build a QR code scanner that reads and decodes QR codes in images or real-time video feeds.',
              image: '/images/qr_scanner.jpg'
            }
          ],
          June: [
            { 
              name: 'Line Follower Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Build a robot that follows a black or white line on the ground using IR sensors.',
              image: '/images/line_follower.jpg'
            },
            { 
              name: 'Obstacle Avoidance Robot', 
              technologies: ['Arduino', 'Ultrasonic Sensor', 'Motors'], 
              description: 'Create a robot that detects and avoids obstacles using an ultrasonic sensor.',
              image: '/images/obstacle_avoidance.jpg'
            },
            { 
              name: 'Light Following Robot', 
              technologies: ['Arduino', 'Light Sensors', 'Motors'], 
              description: 'Design a robot that moves towards a light source using light-dependent resistors (LDRs).',
              image: '/images/light_following.jpg'
            },
            { 
              name: 'Bluetooth-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Motors'], 
              description: 'Build a robot controlled via a smartphone app using Bluetooth communication.',
              image: '/images/bluetooth_robot.jpg'
            },
            { 
              name: 'Remote-Controlled Car', 
              technologies: ['Arduino', 'RF Module', 'Motors'], 
              description: 'Create a robot car that can be controlled remotely using an RF transmitter and receiver.',
              image: '/images/rc_car.jpg'
            },
            { 
              name: 'Basic Robotic Arm', 
              technologies: ['Arduino', 'Servo Motors'], 
              description: 'Build a simple robotic arm with multiple joints that can pick and place objects.',
              image: '/images/robotic_arm.jpg'
            },
            { 
              name: 'Maze Solver Robot', 
              technologies: ['Arduino', 'IR Sensors', 'Motors'], 
              description: 'Develop a robot that can navigate and solve a maze autonomously using IR sensors.',
              image: '/images/maze_solver.jpg'
            },
            { 
              name: 'Voice-Controlled Robot', 
              technologies: ['Arduino', 'Bluetooth Module', 'Speech Recognition'], 
              description: 'Build a robot that responds to voice commands sent from a smartphone app or computer.',
              image: '/images/voice_controlled.jpg'
            }
          ],
        
  
        July: [
          // 8 NLP + ML Hybrid projects
            { 
              name: 'Sentiment Analysis', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Analyze the sentiment (positive, negative, or neutral) of text data such as tweets or product reviews using ML algorithms.',
              image: '/images/sentiment_analysis.jpg'
            },
            { 
              name: 'Spam Email Classifier', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a classifier to distinguish between spam and non-spam emails using text preprocessing and classification algorithms.',
              image: '/images/spam_classifier.jpg'
            },
            { 
              name: 'Text Summarization', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Develop an extractive text summarization tool that generates a concise summary from lengthy documents.',
              image: '/images/text_summarization.jpg'
            },
            { 
              name: 'Named Entity Recognition (NER)', 
              technologies: ['Python', 'spaCy'], 
              description: 'Create an NER system to identify entities like names, locations, and organizations from text.',
              image: '/images/ner_system.jpg'
            },
            { 
              name: 'Chatbot with Machine Learning', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Build a simple chatbot that understands basic user intents and provides predefined responses using ML and NLP techniques.',
              image: '/images/chatbot.jpg'
            },
            { 
              name: 'Language Detection', 
              technologies: ['Python', 'scikit-learn', 'NLTK'], 
              description: 'Build a system to detect the language of a given text using tokenization and feature extraction.',
              image: '/images/language_detection.jpg'
            },
            { 
              name: 'Topic Modeling', 
              technologies: ['Python', 'Gensim', 'NLTK'], 
              description: 'Implement topic modeling on a text dataset using LDA (Latent Dirichlet Allocation) to extract hidden topics.',
              image: '/images/topic_modeling.jpg'
            },
            { 
              name: 'Keyword Extraction', 
              technologies: ['Python', 'spaCy', 'TextRank'], 
              description: 'Develop a system to extract important keywords from a document using NLP algorithms like TextRank.',
              image: '/images/keyword_extraction.jpg'
            }
          ],
          
        August: [
          // 8 Computer Vision-related projects
            { 
              name: 'Face Detection with Real-Time Video', 
              technologies: ['Python', 'OpenCV', 'Haar Cascades'], 
              description: 'Create a real-time face detection system that identifies human faces from webcam footage.',
              image: '/images/face_detection_video.jpg'
            },
            { 
              name: 'Gesture Recognition', 
              technologies: ['Python', 'OpenCV', 'MediaPipe'], 
              description: 'Build a system to recognize hand gestures (e.g., thumbs up, peace sign) using webcam input and MediaPipe.',
              image: '/images/gesture_recognition.jpg'
            },
            { 
              name: 'Object Recognition', 
              technologies: ['Python', 'OpenCV', 'TensorFlow'], 
              description: 'Develop an object recognition system that identifies and labels objects in real-time using pre-trained models like YOLO or SSD.',
              image: '/images/object_recognition.jpg'
            },
            { 
              name: 'Eye Blink Detection', 
              technologies: ['Python', 'OpenCV', 'dlib'], 
              description: 'Create a system that detects eye blinks in real-time, useful for monitoring driver fatigue or creating interactive applications.',
              image: '/images/eye_blink_detection.jpg'
            },
            { 
              name: 'Optical Character Recognition (OCR)', 
              technologies: ['Python', 'OpenCV', 'Tesseract'], 
              description: 'Implement OCR to extract text from images or documents, converting them into editable format.',
              image: '/images/ocr.jpg'
            },
            { 
              name: 'Image Classification', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Build a deep learning-based image classifier to categorize images into predefined classes using CNNs (Convolutional Neural Networks).',
              image: '/images/image_classification.jpg'
            },
            { 
              name: 'Real-Time Object Tracking', 
              technologies: ['Python', 'OpenCV'], 
              description: 'Track moving objects in real-time using algorithms such as KLT Tracker, Meanshift, or CamShift.',
              image: '/images/object_tracking.jpg'
            },
            { 
              name: 'Image Segmentation', 
              technologies: ['Python', 'OpenCV', 'TensorFlow/Keras'], 
              description: 'Perform semantic segmentation on images, where pixels are classified into distinct categories (e.g., road, building, car).',
              image: '/images/image_segmentation.jpg'
            }
          ],
          
        September: [
          // 8 AI-based chatbots projects
            { 
              name: 'Customer Support Chatbot', 
              technologies: ['Python', 'TensorFlow', 'NLTK', 'Flask'], 
              description: 'Build a chatbot that can handle common customer inquiries, provide product details, and assist with support tickets using NLP techniques.',
              image: '/images/customer_support_chatbot.jpg'
            },
            { 
              name: 'Personal Assistant Chatbot', 
              technologies: ['Python', 'TensorFlow', 'spaCy', 'Speech Recognition'], 
              description: 'Create a personal assistant chatbot capable of scheduling meetings, setting reminders, and answering general questions.',
              image: '/images/personal_assistant.jpg'
            },
            { 
              name: 'E-commerce Recommendation Bot', 
              technologies: ['Python', 'scikit-learn', 'Flask'], 
              description: 'Develop an e-commerce chatbot that recommends products based on user preferences and past purchases using machine learning.',
              image: '/images/ecommerce_chatbot.jpg'
            },
            { 
              name: 'Healthcare Assistant Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Create a chatbot that provides basic healthcare advice, such as symptom analysis, health tips, and medication reminders.',
              image: '/images/healthcare_bot.jpg'
            },
            { 
              name: 'Travel Guide Chatbot', 
              technologies: ['Python', 'Dialogflow', 'Flask'], 
              description: 'Build a chatbot that helps users plan their travels by recommending destinations, providing weather updates, and booking accommodations.',
              image: '/images/travel_guide_bot.jpg'
            },
            { 
              name: 'Language Learning Bot', 
              technologies: ['Python', 'TensorFlow', 'NLTK'], 
              description: 'Develop a chatbot that helps users learn a new language by providing quizzes, translation help, and language practice.',
              image: '/images/language_learning_bot.jpg'
            },
            { 
              name: 'Mental Health Chatbot', 
              technologies: ['Python', 'Dialogflow', 'TensorFlow'], 
              description: 'Create a chatbot that provides mental health support, offers advice on stress management, and encourages positive thinking.',
              image: '/images/mental_health_bot.jpg'
            },
            { 
              name: 'Finance Assistant Chatbot', 
              technologies: ['Python', 'Flask', 'scikit-learn'], 
              description: 'Build a finance assistant chatbot that helps users with budgeting, investing advice, and tracking expenses using machine learning models.',
              image: '/images/finance_assistant.jpg'
            },    
        ],

      October: [
        // 8 MERN projects
          { 
            name: 'Personal Portfolio Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a personal portfolio website that showcases your skills, projects, and resume. Integrate a contact form that stores user inquiries in MongoDB.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create a full-stack blog platform where users can write, edit, delete, and comment on posts. Implement user authentication and a dynamic comment section.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'E-commerce Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a simple e-commerce site that allows users to browse products, add items to the cart, and checkout. Use MongoDB to store product and order information.',
            image: '/images/ecommerce_website.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js', 'Socket.io'], 
            description: 'Create a real-time messaging application where users can chat with each other in private rooms. Implement WebSockets for real-time communication.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Task Management Application', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a task management app that allows users to create, edit, and delete tasks. Users can set deadlines and mark tasks as complete.',
            image: '/images/task_management.jpg'
          },
          { 
            name: 'Job Board Website', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Develop a job board website where users can post job listings and apply for jobs. Include filters to search jobs based on categories or locations.',
            image: '/images/job_board.jpg'
          },
          { 
            name: 'Social Media Platform', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Build a basic social media platform where users can create profiles, post content, like, and comment on others’ posts. Implement notifications for new interactions.',
            image: '/images/social_media_platform.jpg'
          },
          { 
            name: 'Online Learning Management System', 
            technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'], 
            description: 'Create an online learning platform where instructors can create courses, and students can enroll and take lessons. Implement course progress tracking and quizzes.',
            image: '/images/learning_management.jpg'
          },
        ],

      November: [
        // 8 Flask projects
          { 
            name: 'Personal Blog', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Create a personal blog where users can write, edit, and delete posts. Implement user authentication and comment sections for posts.',
            image: '/images/personal_blog.jpg'
          },
          { 
            name: 'Task Manager Application', 
            technologies: ['Python', 'Flask', 'SQLite'], 
            description: 'Build a simple task manager application that allows users to create, edit, mark as completed, and delete tasks.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Online Portfolio Website', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Create an online portfolio to showcase projects, experience, and resume. Include a contact form and a blog section for regular updates.',
            image: '/images/portfolio_website.jpg'
          },
          { 
            name: 'Weather Application', 
            technologies: ['Python', 'Flask', 'OpenWeatherMap API'], 
            description: 'Develop a weather forecasting app where users can input their city and view current weather conditions fetched from OpenWeatherMap API.',
            image: '/images/weather_app.jpg'
          },
          { 
            name: 'Recipe Sharing Platform', 
            technologies: ['Python', 'Flask', 'MySQL'], 
            description: 'Create a platform for users to share and browse recipes. Allow users to upload recipes, add ingredients, and share cooking instructions.',
            image: '/images/recipe_sharing.jpg'
          },
          { 
            name: 'Blog with Admin Panel', 
            technologies: ['Python', 'Flask', 'SQLite', 'Flask-Admin'], 
            description: 'Develop a blog with an admin panel that allows administrators to create, edit, and delete blog posts, manage user comments, and moderate content.',
            image: '/images/admin_blog.jpg'
          },
          { 
            name: 'Login and Registration System', 
            technologies: ['Python', 'Flask', 'SQLAlchemy'], 
            description: 'Build a secure login and registration system with password hashing, email verification, and authentication using Flask.',
            image: '/images/login_system.jpg'
          },
          { 
            name: 'Real-time Chat Application', 
            technologies: ['Python', 'Flask', 'Socket.IO'], 
            description: 'Create a real-time chat application where users can send messages in real time using Flask-SocketIO for bi-directional communication.',
            image: '/images/chat_application.jpg'
          },
        ],
    
      December: [
        // 8 Full-stack projects
          { 
            name: 'E-Commerce Website', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build a fully functional e-commerce website with product listings, a shopping cart, user authentication, and an order management system.',
            image: '/images/ecommerce.jpg'
          },
          { 
            name: 'Blog Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a blogging platform where users can create, edit, and delete blog posts. Implement user authentication, comment sections, and categories for posts.',
            image: '/images/blog_platform.jpg'
          },
          { 
            name: 'Social Media App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a social media app where users can create profiles, follow other users, post statuses, and comment on posts.',
            image: '/images/social_media.jpg'
          },
          { 
            name: 'Task Management App', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create a task management application where users can create, edit, and mark tasks as completed. Include user authentication and different user roles.',
            image: '/images/task_manager.jpg'
          },
          { 
            name: 'Real-Time Chat Application', 
            technologies: ['React', 'Node.js', 'Express', 'Socket.io'], 
            description: 'Build a real-time chat application where users can send messages instantly, create private rooms, and share files.',
            image: '/images/chat_application.jpg'
          },
          { 
            name: 'Job Portal', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Develop a job portal where users can post job listings, apply for jobs, and manage their applications. Admin users can manage job postings.',
            image: '/images/job_portal.jpg'
          },
          { 
            name: 'Event Booking System', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Create an event booking system where users can view upcoming events, book tickets, and manage bookings. Admins can manage events and bookings.',
            image: '/images/event_booking.jpg'
          },
          { 
            name: 'Online Learning Platform', 
            technologies: ['React', 'Node.js', 'Express', 'MongoDB'], 
            description: 'Build an online learning platform where instructors can upload courses, and students can enroll in courses, track their progress, and leave reviews.',
            image: '/images/learning_platform.jpg'
          },
        ]
      },
    },
  };
  
  export default hackathonData;
  