import React from 'react';
import { Link } from 'react-router-dom';
import './HackathonYears.css';

function HackathonYears() {
  return (
    <div className="hackathon-years">
      <h2>Select a Hackathon Year</h2>
      <div className="card-container">
        <div className="card">
          <h3>2021</h3>
          <Link to="/2021">
            <button>View Projects</button>
          </Link>
        </div>
        <div className="card">
          <h3>2022</h3>
          <Link to="/2022">
            <button>View Projects</button>
          </Link>
        </div>
        <div className="card">
          <h3>2023</h3>
          <Link to="/2023">
            <button>View Projects</button>
          </Link>
        </div>
        <div className="card">
          <h3>2024</h3>
          <Link to="/2024">
            <button>View Projects</button>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default HackathonYears;
