import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import hackathonData from '../data'; // Assuming your data is stored here
import './YearlyProjects.css';

function YearlyProjects() {
  const { year } = useParams(); // Get the selected year from the URL
  const yearData = hackathonData[year];
  const navigate = useNavigate(); // To navigate programmatically

  if (!yearData) {
    return <div>No data available for {year}</div>;
  }

  const navigateToCategory = (category) => {
    navigate(`/${year}/${category}`);
  };

  return (
    <div className="yearly-projects-container">
      <h2>{year} Hackathon Projects</h2>
      
      {/* Project Categories */}
      <div className="card-container">
        <div className="project-category card">
          <h3>1st Year Projects</h3>
          <p>Innovative projects from our first-years.</p>
          <button 
            className="view-button" 
            onClick={() => navigateToCategory('firstYearProjects')}
          >
            View Projects
          </button>
        </div>
        
        <div className="project-category card">
          <h3>2nd Year Projects</h3>
          <p>Innovative projects from our second-years.</p>
          <button 
            className="view-button" 
            onClick={() => navigateToCategory('secondYearProjects')}
          >
            View Projects
          </button>
        </div>

        <div className="project-category card">
          <h3>3rd Year Projects</h3>
          <p>Innovative projects from our third-years.</p>
          <button 
            className="view-button" 
            onClick={() => navigateToCategory('thirdYearProjects')}
          >
            View Projects
          </button>
        </div>

        <div className="project-category card">
          <h3>4th Year Projects</h3>
          <p>Innovative projects from our fourth-years.</p>
          <button 
            className="view-button" 
            onClick={() => navigateToCategory('fourthYearProjects')}
          >
            View Projects
          </button>
        </div>
      </div>
    </div>
  );
}

export default YearlyProjects;
