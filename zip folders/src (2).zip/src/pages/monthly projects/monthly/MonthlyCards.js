import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import monthlyData from "../data"; // Import the data

function MonthlyCards() {
  const { year, yearName } = useParams(); // Get year and category from the URL
  const monthData = monthlyData[year]?.[yearName] || {}; // Get the data for the selected year and category

  const allMonths = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const formattedYearName = yearName.replace(/([a-z])([A-Z])/g, "$1 $2"); // Format year name

  // Slideshow state
  const [currentIndex, setCurrentIndex] = useState(0);
  const cardsPerSlide = 4;
  const totalSlides = Math.ceil(allMonths.length / cardsPerSlide);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + totalSlides) % totalSlides);
  };

  // Get months for the current slide
  const currentMonths = allMonths.slice(
    currentIndex * cardsPerSlide,
    (currentIndex + 1) * cardsPerSlide
  );

  return (
    <div className="monthly-cards">
      <div className="header-container">
        <h2 className="highlighted-heading">Student Innovation: {formattedYearName}</h2>
      </div>

      {/* Display the months for the current slide */}
      <div className="card-container">
        {currentMonths.map((month, index) => (
          <div
            className="card card-animation"
            style={{ "--card-index": index }}
            key={month}
          >
            {monthData[month] ? (
              <Link to={`/${year}/${yearName}/${month}`} className="card-link">
                <h3>{month}</h3>
                <p>Click to view {month} projects</p>

                {monthData[month]?.technologies &&
                  monthData[month].technologies.length > 0 && (
                    <div className="technologies">
                      <strong>Technologies:</strong>
                      {monthData[month].technologies.join(", ")}
                    </div>
                  )}

                <button className="view-more-button">View More</button>
              </Link>
            ) : (
              <div className="card-disabled">
                <h3>{month}</h3>
                <p>No projects available</p>
                <button className="view-more-button disabled">View More</button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Slideshow controls */}
      <div className="slideshow-controls">
        <button onClick={prevSlide} className="slide-button prev-button">
          Previous
        </button>
        <button onClick={nextSlide} className="slide-button next-button">
          Next
        </button>
      </div>

      {/* Style for the cards */}
      <style jsx>{`
        .monthly-cards {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }

        .header-container {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 15vh; /* Reduced height to move the heading up */
          margin-bottom: 20px; /* Adjusted margin to move heading up */
        }

        .highlighted-heading {
          text-align: center;
          font-size: 2em;
          font-weight: bold;
          color: black;
          text-transform: capitalize;
          letter-spacing: 1px;
          margin-top: 0; /* Remove any top margin to lift the heading up */
        }

        .card-container {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 10px;
          width: 100%;
          margin-top: -5px; /* Adjusted to lift the cards up */
        }

        .card {
          padding: 20px;
          background-color: #f9f9f9;
          border-radius: 8px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          text-align: center;
          transform: translateY(5px); /* Slightly lifted from the original 10px */
          opacity: 0;
          animation: moveUp 0.5s ease-in-out forwards;
        }

        .card-animation {
          animation-delay: calc(var(--card-index, 0) * 0.2s);
        }

        .card:hover {
          transform: translateY(-5px);
          box-shadow: 0 6px 18px rgba(0, 0, 0, 0.2);
        }

        .card-link {
          text-decoration: none;
          color: inherit;
        }

        .view-more-button {
          background-color: #28a745;
          color: white;
          border: none;
          padding: 10px 20px;
          font-size: 1em;
          border-radius: 5px;
          cursor: pointer;
          transition: background-color 0.3s ease;
          margin-top: 1px;
        }

        .view-more-button:hover {
          background-color: #218838;
        }

        .view-more-button.disabled {
          background-color: #ccc;
          cursor: not-allowed;
        }

        .slideshow-controls {
          display: flex;
          justify-content: center;
          align-items: center;
          margin-top: 20px;
        }

        .slide-button {
          background-color: rgb(55, 130, 209);
          color: white;
          border: none;
          padding: 10px 25px;
          font-size: 1.2em;
          font-weight: bold;
          cursor: pointer;
          border-radius: 8px;
          transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.2s ease;
          margin: 0 10px;
        }

        .slide-button:hover {
          background-color: rgb(30, 122, 221);
          transform: translateY(-2px);
          box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
        }

        @keyframes moveUp {
          0% {
            transform: translateY(5px); /* Slightly lifted from the original 10px */
            opacity: 0;
          }
          100% {
            transform: translateY(0);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}

export default MonthlyCards;
