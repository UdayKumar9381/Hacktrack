import React from 'react';
import { Link } from 'react-router-dom';
import './Headers.css';

function Header() {
  return (
    <header className="header">
      <h1>Welcome to Monthly Projects</h1>
      <p>Explore Our Monthly Projects Collection</p>
      <nav>
        <ul className="nav-list">
          <li><Link to="/" className="nav-link">Home</Link></li>
          <li><Link to="/2021" className="nav-link">2021</Link></li>
          <li><Link to="/2022" className="nav-link">2022</Link></li>
          <li><Link to="/2023" className="nav-link">2023</Link></li>
          <li><Link to="/2024" className="nav-link">2024</Link></li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
