import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Homepage from './pages/homepage/Homepage';
import UserAccountPage from './pages/navbar container/userProfile/UserAccountPage';
import ResourcePage from './pages/resource/res'; // Corrected import for the Resource Page
import MonthlyCards from './pages/monthly projects/ap1';

import RegisterPage from './pages/hackathonRegistration/RegisterPage';
import OngoingHackathonPage from './pages/ongoinghackathon/OngoingHackathonPage';
import HackathonGuidesPage from './pages/footer container/hackathonGuides/hackathonGuidesPage';
import SignupPage from './pages/navbar container/signup/signup';
import LoginPages from './pages/navbar container/loginpage/logins';
import HostHackathon from './pages/footer container/host_hackathon/host_hackathon';
import ExploreProjectsPage from './pages/footer container/explore projects/ExploreProjectsPage';
import BrowseHackathonPage from './pages/footer container/browse_hackathon/BrowseHackathonPage';
import AboutHackathon from './pages/footer container/about/about_hackathon';
import Careers from './pages/footer container/careers/Careers';
import ContactPage from './pages/footer container/contact frontend/ContactPage';
import Help from './pages/footer container/help/Help';
import Present from './components/hackathonSection/present/Present';
import Past from './components/hackathonSection/past/Past';
import Future from './components/hackathonSection/future/Future';
import Regester from './components/hackathonSection/Register/Regester.js';
import Reglist from './components/hackathonSection/RegisterList/Reglist.js';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/login" element={<LoginPages />} />
        <Route path="/account" element={<UserAccountPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/resource" element={<ResourcePage />} /> {/* Corrected path */}
        <Route path= "/monthly projects/*" element={<MonthlyCards />} />
        <Route path="/ongoing" element={<OngoingHackathonPage />} />
        <Route path="/hackathon-guides" element={<HackathonGuidesPage />} />
        <Route path="/host-hackathon" element={<HostHackathon />} />
  <Route path="/explore-projects" element={<ExploreProjectsPage />} />
        <Route path="/browse-hackathon" element={<BrowseHackathonPage />} />
        <Route path="/about" element={<AboutHackathon />} />
        <Route path="/careers" element={<Careers />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/help" element={<Help />} />
        <Route path="/present" element={<Present />} />
        <Route path="/past" element={<Past />} />
        <Route path="/future" element={<Future />} />
        <Route path="/regester" element={<Regester/>} />
        <Route path="/register-list" element={<Reglist/>} />
        
      </Routes>
    </Router>
  );
}

export default App;
