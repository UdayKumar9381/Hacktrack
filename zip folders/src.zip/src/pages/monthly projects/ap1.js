import React from 'react';
import { Route, Routes } from 'react-router-dom'; // Remove Outlet import
import Header from './monthly/Headers';
import HackathonYears from './monthly/HackathonYears';
import YearlyProjects from './monthly/YearlyProjects';
import MonthlyCards from './monthly/MonthlyCards';
import Projectcard from './monthly/Projectcard';
import './main.css'; // Import the global CSS

function App() {
  return (
    <>
      <Header />
      <div className="container">
        <Routes>
          {/* Base route for Hackathon Years */}
          <Route path="/" element={<HackathonYears />} />

          {/* Dynamic routes */}
          <Route path="/:year" element={<YearlyProjects />} />
          <Route path="/:year/:yearName" element={<MonthlyCards />} />
          <Route path="/:year/:yearName/:month" element={<Projectcard />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
