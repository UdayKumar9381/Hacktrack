import React from 'react';
import { useParams } from 'react-router-dom';
import hackathonData from '../data'; // Assuming data contains your project details

const ProjectCards = () => {
  const { year, yearName, month } = useParams(); // Get year, category, and month from the URL
  const projectDetails = hackathonData[year]?.[yearName]?.[month]; // Safely access projects for the selected month

  if (!projectDetails || projectDetails.length === 0) {
    return <div style={styles.noProjects}>No projects available for {month}</div>;
  }

  return (
    <div style={styles.projectCardsContainer}>
      <h2 style={styles.projectHeader}>{month} Projects</h2>
      <div style={styles.projectCards}>
        {projectDetails.map((project, index) => (
          <div style={styles.projectCard} key={index}>
            {/* Project Image */}
            {project.image && (
              <div style={styles.projectImage}>
                <img src={project.image} alt={project.name} style={styles.image} />
              </div>
            )}

            {/* Project Content */}
            <div style={styles.cardContent}>
              <h3 style={styles.cardTitle}>
                {project.name === 'NLP Project 1' ? (
                  <span style={styles.boldTitle}>{project.name}</span>
                ) : (
                  project.name
                )}
              </h3>
              <p><strong>Technologies:</strong> {project.technologies.join(', ')}</p>
              <p><strong>Description:</strong> {project.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const styles = {
  projectCardsContainer: {
    width: '90%',
    margin: '0 auto',
    padding: '20px',
  },
  projectHeader: {
    textAlign: 'center',
    fontSize: '2rem',
    marginBottom: '20px',
    color: '#333',
  },
  projectCards: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    gap: '20px',
  },
  projectCard: {
    width: '22%',
    marginBottom: '20px',
    border: '1px solid #ccc',
    borderRadius: '8px',
    overflow: 'hidden',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    transition: 'transform 0.3s ease-in-out',
  },
  projectImage: {
    height: '200px', // Increased height of the image
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  cardContent: {
    padding: '15px',
  },
  cardTitle: {
    fontSize: '1.25rem', // Adjusted font size
    marginBottom: '5px',
    fontWeight: 'bold', // Default weight
  },
  boldTitle: {
    fontWeight: 'bold', // Bold style for "NLP Project 1"
  },
  noProjects: {
    textAlign: 'center',
    color: '#f00',
    fontSize: '1.5rem',
  },

  // Responsive Styles

  '@media (max-width: 1200px)': {
    projectCard: {
      width: '30%', // Show 3 cards per row on medium screens
    },
  },

  '@media (max-width: 900px)': {
    projectCard: {
      width: '45%', // Show 2 cards per row on small screens
    },
  },

  '@media (max-width: 600px)': {
    projectCard: {
      width: '200%', // Show 1 card per row on very small screens (mobile)
    },
    projectHeader: {
      fontSize: '1.5rem', // Smaller header for mobile
    },
    cardTitle: {
      fontSize: '1.1rem', // Smaller font size for mobile cards
    },
  },
};

export default ProjectCards;
