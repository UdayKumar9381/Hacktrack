import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Header.css';

function Header() {
  const [dropdown, setDropdown] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  const toggleDropdown = (menu) => {
    setDropdown(dropdown === menu ? null : menu);
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const goToLogin = () => {
    navigate('/login');
  };

  const goToUserAccount = () => {
    navigate('/account');
  };

  const goToResources = () => {
    navigate('/resource');
    setMenuOpen(false); // Close menu after navigation
  };

  const handleMenuItemClick = (path) => {
    navigate(path);
    setMenuOpen(false); // Close menu after navigation
  };

  return (
    <header className="header">
      <div className="header-left">
        <button className="hamburger-menu" onClick={toggleMenu}>
          &#9776;
        </button>
        <div className={`menu-items ${menuOpen ? 'show' : ''}`}>
          <div className="menu-box" onClick={() => toggleDropdown('projects')}>
            Projects
            {dropdown === 'projects' && (
              <div className="dropdown-menu">
                <div
                  className="dropdown-item"
                  onClick={() => handleMenuItemClick('/explore-projects')}
                >
                  Top Projects
                </div>
                <div
                  className="dropdown-item"
                  onClick={() => handleMenuItemClick('/monthly-projects')}
                >
                  Monthly Projects
                </div>
              </div>
            )}
          </div>

          <div className="menu-box" onClick={() => toggleDropdown('hackathons')}>
            Hackathons
            {dropdown === 'hackathons' && (
              <div className="dropdown-menu">
                <div className="dropdown-item">Teams</div>
                <div className="dropdown-item">Winners</div>
                <div className="dropdown-item">Mentors</div>
              </div>
            )}
          </div>

          <div className="menu-box" onClick={() => toggleDropdown('coding')}>
            Coding
            {dropdown === 'coding' && (
              <div className="dropdown-menu">
                <div className="dropdown-item">Live Contest</div>
                <div className="dropdown-item">Previous Contests</div>
                <div className="dropdown-item">Winners</div>
                <div className="dropdown-item">Leaderboard</div>
              </div>
            )}
          </div>

          <div className="menu-box" onClick={goToResources}>
            Resource
          </div>
        </div>
      </div>
      <div className="header-right">
        <input type="text" placeholder="Search..." className="search-bar" />
        <div className="user-account" onClick={goToUserAccount}>
          User Account
        </div>
        <button className="login-btn" onClick={goToLogin}>
          Login
        </button>
      </div>
    </header>
  );
}

export default Header;